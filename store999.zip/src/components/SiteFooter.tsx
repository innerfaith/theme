import { useState } from "react";
import { Link, useLocation } from "@tanstack/react-router";
import { Truck, ShieldCheck, RotateCcw, Smile, ArrowUp, Facebook, Twitter, Instagram, Youtube, Linkedin, MessageCircle } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const TRUST = [
  { icon: Smile, title: "2M+ Satisfied Customers", text: "Thrilled to bring a smile to our millions customer!", mobileTitle: "2M+ Satisfied Customers", mobileText: "Thrilled to bring a smile to our millions customer!" },
  { icon: Truck, title: "Free Shipping", text: "Free shipping on orders above Rs. 599/- Pan INDIA", mobileText: "Free shipping on orders above Rs. 599/- Pan INDIA" },
  { icon: ShieldCheck, title: "Secured Payment", text: "Secure and trusted payment options – guaranteed." },
  { icon: RotateCcw, title: "Easy Returns", text: "Buy with confidence – easy return & replacement." },
];

const SOCIALS = [
  { icon: Facebook, label: "Facebook" },
  { icon: Twitter, label: "X" },
  { icon: Instagram, label: "Instagram" },
  { icon: Youtube, label: "YouTube" },
  { icon: Linkedin, label: "LinkedIn" },
  { icon: MessageCircle, label: "WhatsApp" },
];

const POLICIES = [
  "Terms & Conditions",
  "Shipping Policy",
  "Return & Refund Policy",
  "Payment & Security",
  "Privacy Policy",
  "Order Cancellation Policy",
  "Grievance Redressal Policy",
];

const QUICK_LINKS = [
  { label: "All Collections", to: "/collections" },
  { label: "New Arrivals", to: "/collections/$slug", slug: "new-arrivals" },
  { label: "Viral Gadgets", to: "/collections/$slug", slug: "electronic-gadgets" },
  { label: "Trending Products", to: "/collections/$slug", slug: "trending-products" },
  { label: "On Sale", to: "/collections/$slug", slug: "on-sale" },
  { label: "Hot Selling", to: "/collections/$slug", slug: "best-sellers" },
];

const IMPORTANT_LINKS = [
  "About Us",
  "Contact Us",
  "Sell to Us",
  "Influencer Collaboration",
  "Affiliates",
  "FAQs",
  "Jobs @ BulkBazaar",
];

const COLUMN_HEADINGS = ["Reach Us", "Policies", "Quick links", "Important Links"] as const;

function ReachUs() {
  return (
    <div>
      <h2 className="text-base font-bold text-foreground">Reach Us</h2>
      <p className="mt-6 text-sm leading-6 text-muted-foreground">Whatsapp: +91 00000 00000</p>
      <p className="mt-6 text-sm font-bold leading-6 text-foreground">Working Days / Hours:</p>
      <p className="mt-1 text-sm leading-6 text-muted-foreground">Monday–Saturday / 9.30 am - 6.00 pm</p>
      <p className="mt-6 text-sm font-bold leading-6 text-foreground">BulkBazaar</p>
      <div className="mt-8 flex flex-wrap gap-3">
        {SOCIALS.map(({ icon: Icon, label }) => (
          <Button
            key={label}
            variant="ghost"
            size="icon"
            type="button"
            aria-label={label}
            className="h-10 w-10 rounded-full bg-muted text-foreground shadow-none hover:bg-foreground/10"
          >
            <Icon className="h-4 w-4" />
          </Button>
        ))}
      </div>
    </div>
  );
}

function StaticList({ items }: { items: string[] }) {
  return (
    <ul className="space-y-4">
      {items.map((item) => (
        <li key={item} className="text-sm leading-6 text-muted-foreground">{item}</li>
      ))}
    </ul>
  );
}

function QuickLinksList() {
  return (
    <ul className="space-y-4">
      {QUICK_LINKS.map((item) => (
        <li key={item.label}>
          {item.slug ? (
            <Link to="/collections/$slug" params={{ slug: item.slug }} className="text-sm leading-6 text-muted-foreground transition-colors hover:text-foreground">
              {item.label}
            </Link>
          ) : (
            <Link to="/collections" className="text-sm leading-6 text-muted-foreground transition-colors hover:text-foreground">
              {item.label}
            </Link>
          )}
        </li>
      ))}
    </ul>
  );
}

export function SiteFooter() {
  const [active, setActive] = useState(0);
  const pathname = useLocation({ select: (l) => l.pathname });
  return (
    <footer>
      {pathname === "/" && (
      <section className="border-y bg-nav">
        <div
          id="trust-strip"
          onScroll={(e) => setActive(Math.min(TRUST.length - 1, Math.round(e.currentTarget.scrollLeft / (e.currentTarget.clientWidth / 2))))}
          className="mx-auto flex max-w-7xl snap-x snap-mandatory overflow-x-auto px-0 pb-4 pt-8 [scrollbar-width:none] md:grid md:grid-cols-4 md:gap-6 md:overflow-visible md:px-4 md:py-6 [&::-webkit-scrollbar]:hidden"
        >
          {TRUST.map(({ icon: Icon, title, text, mobileTitle, mobileText }) => (
            <div key={title} className="flex w-1/2 shrink-0 snap-start flex-col items-center px-2 text-center md:w-auto md:px-0">
              <span className="flex h-16 w-16 items-center justify-center rounded-full bg-background md:h-14 md:w-14"><Icon className="h-7 w-7 text-muted-foreground md:h-6 md:w-6" /></span>
              <p className="mt-3 text-base font-bold leading-tight md:text-sm"><span className="md:hidden">{mobileTitle ?? title}</span><span className="hidden md:inline">{title}</span></p>
              <p className="mt-1 text-sm leading-7 text-foreground md:max-w-60 md:text-xs md:leading-relaxed md:text-muted-foreground"><span className="md:hidden">{mobileText ?? text}</span><span className="hidden md:inline">{text}</span></p>
            </div>
          ))}
        </div>
        <div className="flex items-center justify-center gap-4 pb-8 md:hidden">
          {TRUST.map((t, i) => (
            <Button
              variant="ghost"
              size="icon"
              key={t.title}
              type="button"
              aria-label={`Show ${t.title}`}
              onClick={() => {
                const el = document.getElementById("trust-strip");
                el?.scrollTo({ left: (i * el.clientWidth) / 2, behavior: "smooth" });
              }}
              className="h-8 w-8 rounded-full hover:bg-foreground/10"
            >
              {i === active ? <span className="flex h-4 w-4 items-center justify-center rounded-full border border-foreground"><span className="h-1.5 w-1.5 rounded-full bg-foreground" /></span> : <span className="h-1.5 w-1.5 rounded-full bg-muted-foreground/40" />}
            </Button>
          ))}
        </div>
      </section>
      )}
      <section className="bg-background text-foreground">
        <div className="mx-auto max-w-7xl px-6 pb-8 pt-10 md:px-4 md:pb-12 md:pt-14">
          <div className="grid gap-10 md:grid-cols-4 md:gap-8 lg:gap-16">
            <ReachUs />
            <div className="hidden md:block">
              <h2 className="text-base font-bold text-foreground">Policies</h2>
              <div className="mt-6"><StaticList items={POLICIES} /></div>
            </div>
            <div className="hidden md:block">
              <h2 className="text-base font-bold text-foreground">Quick links</h2>
              <div className="mt-6"><QuickLinksList /></div>
            </div>
            <div className="hidden md:block">
              <h2 className="text-base font-bold text-foreground">Important Links</h2>
              <div className="mt-6"><StaticList items={IMPORTANT_LINKS} /></div>
            </div>
          </div>
          <Accordion type="multiple" className="mt-8 md:hidden">
            {COLUMN_HEADINGS.slice(1).map((heading, i) => (
              <AccordionItem key={heading} value={heading} className="border-border">
                <AccordionTrigger className="py-5 text-base font-bold hover:no-underline">{heading}</AccordionTrigger>
                <AccordionContent>
                  <nav aria-label={`Footer ${heading}`}>
                    {i === 0 && <StaticList items={POLICIES} />}
                    {i === 1 && <QuickLinksList />}
                    {i === 2 && <StaticList items={IMPORTANT_LINKS} />}
                  </nav>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
        <div className="border-t border-border">
          <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-6 py-5 md:px-4">
            <p className="text-xs leading-5 text-muted-foreground">© {new Date().getFullYear()} BulkBazaar.<br className="md:hidden" /> All rights reserved.</p>
            <Button variant="ghost" className="h-10 gap-2 px-2 text-xs text-foreground hover:bg-foreground/10 hover:text-foreground" onClick={() => window.scrollTo({ top: 0, behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "instant" : "smooth" })}>
              Back to top <ArrowUp className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </section>
    </footer>
  );
}

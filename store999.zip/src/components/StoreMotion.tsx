import { useLocation } from "@tanstack/react-router";
import { useEffect } from "react";

/** Progressive enhancement: content stays visible without animation support. */
export function StoreMotion() {
  const pathname = useLocation({ select: (location) => location.pathname });

  useEffect(() => {
    const preference = window.matchMedia("(prefers-reduced-motion: reduce)");
    if (preference.matches || typeof IntersectionObserver === "undefined") return;

    const seen = new WeakSet<Element>();
    const active = new Set<Animation>();
    const targetAnimations = new WeakMap<Element, Animation>();
    const tokens = getComputedStyle(document.documentElement);
    const easing = tokens.getPropertyValue("--motion-ease").trim() || "ease-out";
    const durationToken = tokens.getPropertyValue("--motion-reveal-duration").trim();
    const duration = (parseFloat(durationToken) * (durationToken.endsWith("ms") ? 1 : 1000)) || 640;
    const distance = tokens.getPropertyValue("--motion-reveal-distance").trim() || "24px";
    const staggerToken = tokens.getPropertyValue("--motion-reveal-stagger").trim();
    const staggerStep = (parseFloat(staggerToken) * (staggerToken.endsWith("ms") ? 1 : 1000)) || 55;
    let frame = 0;
    let entered = false;

    const play = (element: Element, keyframes: Keyframe[], duration: number, delay = 0) => {
      if (typeof element.animate !== "function" || preference.matches) return;
      const animation = element.animate(keyframes, { duration, delay, easing, fill: "backwards" });
      active.add(animation);
      targetAnimations.set(element, animation);
      animation.onfinish = () => active.delete(animation);
      animation.oncancel = () => active.delete(animation);
    };

    const observer = new IntersectionObserver((entries) => {
      const visible = entries.filter((entry) => entry.isIntersecting)
        .sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top || a.boundingClientRect.left - b.boundingClientRect.left);
      let rowTop = -Infinity;
      let column = 0;
      for (const entry of visible) {
        observer.unobserve(entry.target);
        // Hidden alternate phone/desktop sections must remain eligible if the viewport changes.
        if (entry.boundingClientRect.width === 0 || entry.boundingClientRect.height === 0) {
          seen.delete(entry.target);
          continue;
        }
        if (Math.abs(entry.boundingClientRect.top - rowTop) > 32) {
          rowTop = entry.boundingClientRect.top;
          column = 0;
        }
        const heading = entry.target.matches("h1, h2");
        const focused = entry.target.contains(document.activeElement);
        if (focused) continue;
        // Never transform a page container: its fixed filter trigger must stay viewport-fixed.
        play(entry.target, [
          { opacity: 0, translate: `0 ${heading ? "6px" : distance}`, scale: "1" },
          { opacity: 1, translate: "0 0", scale: "1" },
        ], heading ? duration * 0.8 : duration, Math.min(column++ * staggerStep, 165));
      }
    }, { threshold: 0.06, rootMargin: "0px 0px -24px 0px" });

    const scan = () => {
      const main = document.querySelector("main");
      if (!main) return;
      if (!entered) {
        entered = true;
        play(main, [{ opacity: 0.65 }, { opacity: 1 }], 240);
      }
      main.querySelectorAll("h1, h2, .mobile-product-card, .budget-tile, [data-store-reveal]").forEach((element) => {
        if (seen.has(element)) return;
        seen.add(element);
        observer.observe(element);
      });
    };
    const scheduleScan = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(scan);
    };
    const mutations = new MutationObserver(scheduleScan);
    mutations.observe(document.body, { childList: true, subtree: true });
    const revealFocused = (event: FocusEvent) => {
      if (!(event.target instanceof Element)) return;
      const target = event.target.closest(".mobile-product-card, .budget-tile, [data-store-reveal]");
      if (target) targetAnimations.get(target)?.cancel();
    };
    document.addEventListener("focusin", revealFocused);
    window.addEventListener("resize", scheduleScan, { passive: true });
    const stop = () => {
      if (!preference.matches) return;
      observer.disconnect();
      mutations.disconnect();
      cancelAnimationFrame(frame);
      active.forEach((animation) => animation.cancel());
      document.removeEventListener("focusin", revealFocused);
      window.removeEventListener("resize", scheduleScan);
    };
    preference.addEventListener("change", stop);
    scheduleScan();

    return () => {
      observer.disconnect();
      mutations.disconnect();
      cancelAnimationFrame(frame);
      active.forEach((animation) => animation.cancel());
      document.removeEventListener("focusin", revealFocused);
      window.removeEventListener("resize", scheduleScan);
      preference.removeEventListener("change", stop);
    };
  }, [pathname]);

  return null;
}
import { useEffect, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { ChevronDown, Heart, Menu, Minus, Plus, Search, User, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { CartDrawer } from "@/components/CartDrawer";
import { MENU_GROUPS, slugFor } from "@/lib/collections";
import { Sheet, SheetClose, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";

const ANNOUNCEMENTS = [
  "Welcome to our store",
  "Products starting @ just Rs. 29/-",
  "Free shipping on orders above Rs. 495/-",
  "COD option available on orders above Rs. 295/-",
  "Easy return policy",
];

const NAV = ["New Arrivals", "Trending Products", "Electronic Gadgets", "Shop by Collection", "On Sale", "Shop by Price", "Shop by Industry", "Best Sellers", "Home & Kitchen"];

const toHref = (c: { slug?: string; max?: number }) => (c.slug ? `/collections/${c.slug}` : `/?max=${c.max}`);
const MOBILE_MENU: { label: string; children?: { label: string; href: string }[] }[] = [
  { label: "New Arrivals" },
  { label: "Trending Gadgets" },
  { label: "Electronic Gadgets" },
  { label: "Shop by Collection", children: (MENU_GROUPS["Shop by Collection"] ?? []).map((c) => ({ label: c.label, href: toHref(c) })) },
  { label: "On sale" },
  { label: "Shop by Price", children: (MENU_GROUPS["Shop by Price"] ?? []).map((c) => ({ label: c.label, href: toHref(c) })) },
  { label: "Shop by Industry", children: (MENU_GROUPS["Shop by Industry"] ?? []).map((c) => ({ label: c.label, href: toHref(c) })) },
  { label: "Best Sellers" },
  { label: "Home & Kitchen" },
];

export function SiteHeader() {
  const [showBar, setShowBar] = useState(true);
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [expanded, setExpanded] = useState<string | null>(null);
  const [q, setQ] = useState("");
  const navigate = useNavigate();

  // Bottom-nav "Search" opens this search bar via a window event.
  useEffect(() => {
    const open = () => setSearchOpen(true);
    window.addEventListener("bb:open-search", open);
    return () => window.removeEventListener("bb:open-search", open);
  }, []);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchOpen(false);
    navigate({ to: "/", search: { q: q || undefined } });
  };

  const searchForm = (isMobile: boolean) => (
    <form
      className={isMobile ? "flex flex-1 items-center gap-2" : "mx-auto hidden w-full max-w-lg items-center rounded-sm border border-input md:flex"}
      onSubmit={submit}
    >
      <input
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder="Search product"
        autoFocus={isMobile}
        className={isMobile ? "h-10 flex-1 rounded-sm border border-input bg-transparent px-3 text-sm outline-none" : "h-9 min-w-0 flex-1 bg-transparent px-3 text-xs outline-none"}
      />
      <Button variant="ghost" type="submit" aria-label="Search" className={isMobile ? "px-2" : "px-4"}>
        <Search className="h-5 w-5" />
      </Button>
      {isMobile && (
        <Button variant="ghost" type="button" aria-label="Close search" onClick={() => setSearchOpen(false)} className="px-2">
          <X className="h-5 w-5" />
        </Button>
      )}
    </form>
  );

  return (
    <header className="sticky top-0 z-40 bg-background">
      {showBar && (
        <div className="relative flex h-7 items-center overflow-hidden bg-announce text-announce-foreground">
          <div className="flex w-max animate-marquee whitespace-nowrap">
            {[...ANNOUNCEMENTS, ...ANNOUNCEMENTS].map((a, i) => (
              <span key={i} className="flex items-center text-[9px] font-bold uppercase md:text-xs">
                <span className="px-6">{a}</span>
                <span className="h-px w-8 bg-announce-foreground/60" />
              </span>
            ))}
          </div>
          <Button variant="ghost" onClick={() => setShowBar(false)} aria-label="Close announcement" className="absolute right-0 h-full bg-announce px-3">
            <X className="h-4 w-4" />
          </Button>
        </div>
      )}
      <div className="mx-auto grid max-w-7xl grid-cols-[auto_1fr_auto] items-center gap-2 px-3 py-2 md:flex md:gap-6 md:px-4 md:py-3">
        <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="h-8 w-8 md:hidden" aria-label="Open menu">
              <Menu className="h-6 w-6" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-[88%] max-w-sm p-0 [&>button]:hidden">
            <div className="flex h-full flex-col overflow-y-auto px-4 pb-6 pt-4">
              <SheetTitle className="sr-only">Menu</SheetTitle>
              <SheetClose asChild>
                <Button variant="ghost" size="icon" aria-label="Close menu" className="-ml-2 h-9 w-9 [&_svg]:size-6"><X className="h-6 w-6" strokeWidth={1.5} /></Button>
              </SheetClose>
              <nav className="mt-4">
                {MOBILE_MENU.map((m) => (
                  <div key={m.label} className="border-b border-foreground/60">
                    {m.children ? (
                      <>
                        <button type="button" onClick={() => setExpanded((e) => (e === m.label ? null : m.label))} aria-expanded={expanded === m.label} className="flex w-full items-center justify-between py-3 text-left text-sm">
                          {m.label}
                          {expanded === m.label ? <Minus className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
                        </button>
                        {expanded === m.label && (
                          <div className="pb-2 pl-3">
                            {m.children.map((c) => (
                              <a key={c.label} href={c.href} onClick={() => setMenuOpen(false)} className="block py-1.5 text-sm text-muted-foreground">{c.label}</a>
                            ))}
                          </div>
                        )}
                      </>
                    ) : (
                      <Link to="/collections/$slug" params={{ slug: slugFor(m.label) }} onClick={() => setMenuOpen(false)} className="block py-3 text-sm" activeProps={{ className: "text-sale" }}>{m.label}</Link>
                    )}
                  </div>
                ))}
              </nav>
              <div className="mt-3 flex gap-2">
                <button type="button" onClick={() => { setMenuOpen(false); toast("Wishlist coming soon!", { position: "top-center" }); }} className="flex items-center gap-1.5 rounded-full border border-foreground px-4 py-2 text-sm"><Heart className="h-4 w-4" />Wishlist</button>
                <button type="button" onClick={() => { setMenuOpen(false); setSearchOpen(true); }} className="flex items-center gap-1.5 rounded-full border border-foreground px-4 py-2 text-sm"><Search className="h-4 w-4" />Search</button>
              </div>
              <p className="mt-6 text-sm font-semibold text-muted-foreground underline underline-offset-4">Need help ?</p>
              <p className="mt-3 text-xs font-semibold text-muted-foreground">Whatsapp: +91 00000 00000</p>
              <div className="mt-auto border-b border-foreground/60 pb-6 pt-10">
                <button type="button" onClick={() => { setMenuOpen(false); toast("Account coming soon!", { position: "top-center" }); }} className="flex items-center gap-1.5 rounded-full border border-foreground px-4 py-2 text-sm"><User className="h-4 w-4" />Account</button>
              </div>
            </div>
          </SheetContent>
        </Sheet>
        <Link to="/" className="flex min-w-0 flex-col items-center justify-center leading-none md:items-start">
          <span className="text-lg font-extrabold md:text-2xl">
            <span className="text-sale">Bulk</span>Bazaar
          </span>
          <span className="text-[8px] font-bold italic text-muted-foreground md:text-[11px]">Bachat ka smart tareeka!</span>
        </Link>
        {searchForm(false)}
        <div className="flex items-center justify-end gap-1 md:shrink-0 md:gap-3">
          <Button variant="ghost" onClick={() => setSearchOpen((v) => !v)} size="icon" aria-label="Search" className="h-8 w-8 md:hidden">
            <Search className="h-5 w-5" />
          </Button>
          <span className="hidden items-center gap-1.5 text-sm font-medium lg:flex"><User className="h-5 w-5" />Account</span>
          <span className="hidden items-center gap-1.5 text-sm font-medium lg:flex"><Heart className="h-5 w-5" />Wishlist</span>
          <CartDrawer />
        </div>
      </div>
      {searchOpen && (
        <div className="border-t px-4 py-2 md:hidden">{searchForm(true)}</div>
      )}
      <nav className="hidden bg-nav md:block">
        <div className="mx-auto flex max-w-7xl flex-nowrap items-center justify-center gap-x-2.5 px-4 py-3 text-[10px] font-medium lg:gap-x-3.5 lg:text-xs">
          {NAV.map((n) => (
            MENU_GROUPS[n] ? (
              <div key={n} className="group/menu relative">
                <button type="button" aria-haspopup="true" className="flex items-center gap-1 whitespace-nowrap border-b border-transparent py-0.5 transition-colors hover:text-sale group-hover/menu:border-foreground group-focus-within/menu:border-foreground">
                  {n}<ChevronDown className="h-3 w-3 transition-transform duration-200 group-hover/menu:rotate-180" />
                </button>
                <div className="invisible absolute left-0 top-full z-50 pt-3 opacity-0 transition-all duration-200 group-hover/menu:visible group-hover/menu:opacity-100 group-focus-within/menu:visible group-focus-within/menu:opacity-100">
                  <ul className="min-w-56 translate-y-1 border bg-popover py-3 text-popover-foreground shadow-lg transition-transform duration-200 group-hover/menu:translate-y-0">
                    {MENU_GROUPS[n].map((c) => (
                      <li key={c.label}>
                        {c.slug ? (
                          <Link to="/collections/$slug" params={{ slug: c.slug }} className="block px-5 py-2 text-xs text-muted-foreground transition-colors hover:bg-muted hover:text-sale lg:text-[13px]" activeProps={{ className: "text-sale" }}>{c.label}</Link>
                        ) : (
                          <Link to="/" search={{ max: c.max }} className="block px-5 py-2 text-xs text-muted-foreground transition-colors hover:bg-muted hover:text-sale lg:text-[13px]">{c.label}</Link>
                        )}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ) : (
              <Link key={n} to="/collections/$slug" params={{ slug: slugFor(n) }} className="flex items-center gap-1 whitespace-nowrap transition-colors hover:text-sale" activeProps={{ className: "text-sale" }}>{n}</Link>
            )
          ))}
        </div>
      </nav>
    </header>
  );
}

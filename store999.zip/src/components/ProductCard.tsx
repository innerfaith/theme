import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowUpRight, ChevronLeft, ChevronRight, Eye, Heart, Loader2, Minus, Plus } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { useWishlistStore } from "@/stores/wishlistStore";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { type ShopifyProduct } from "@/lib/shopify";
import { useCartStore } from "@/stores/cartStore";

const rs = (amount: string) => new Intl.NumberFormat("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(parseFloat(amount));

export function ProductCard({ product, framed = false, mobileFramed = false, mobileStacked = false, mobileQuickAdd = false }: { product: ShopifyProduct; framed?: boolean; mobileFramed?: boolean; mobileStacked?: boolean; mobileQuickAdd?: boolean }) {
  const addItem = useCartStore((s) => s.addItem);
  const isLoading = useCartStore((s) => s.isLoading);
  const p = product.node;
  const variant = p.variants.edges[0]?.node;
  const image = p.images.edges[0]?.node;
  const price = variant?.price ?? p.priceRange.minVariantPrice;
  const compare = variant?.compareAtPrice;
  const discount =
    compare && parseFloat(compare.amount) > parseFloat(price.amount)
      ? Math.round((1 - parseFloat(price.amount) / parseFloat(compare.amount)) * 100)
      : 0;
  const soldOut = !variant?.availableForSale;
  const [quickView, setQuickView] = useState(false);
  const [hydrated, setHydrated] = useState(false);
  useEffect(() => setHydrated(true), []);
  const wished = useWishlistStore((s) => s.handles.includes(p.handle)) && hydrated;
  const toggleWish = useWishlistStore((s) => s.toggle);
  const onWish = () => {
    const added = toggleWish(p.handle);
    toast.success(added ? "Added to wishlist" : "Removed from wishlist", { position: "top-center" });
  };
  const actionBtn = "flex h-10 w-10 items-center justify-center rounded-full bg-background text-foreground shadow-md transition-all duration-300 hover:bg-foreground hover:text-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring max-md:h-8 max-md:w-8 md:h-11 md:w-11";

  const [qty, setQty] = useState(1);
  const [imgIdx, setImgIdx] = useState(0);
  const images = p.images.edges.map((e) => e.node);
  const handleAdd = async (quantity = 1) => {
    if (!variant) return;
    await addItem({
      product,
      variantId: variant.id,
      variantTitle: variant.title,
      price: variant.price,
      quantity,
      selectedOptions: variant.selectedOptions || [],
    });
    toast.success(`${p.title} added to cart`, { position: "top-center" });
  };

  return (
    <div className={`group flex min-w-0 flex-col rounded-sm border border-input bg-card p-1.5 md:border-transparent md:p-0 ${framed ? "catalog-featured" : ""} ${mobileFramed ? "mobile-featured" : ""} ${mobileStacked ? "mobile-stacked" : ""} ${mobileQuickAdd ? "mobile-quick-add" : ""} mobile-product-card`}>
      <div className="card-media relative overflow-hidden rounded-sm bg-muted">
      <Link to="/product/$handle" params={{ handle: p.handle }} className="relative block">
        <div className="aspect-square">
          {image ? (
            <img src={image.url} alt={image.altText ?? p.title} loading="lazy" className="h-full w-full object-cover transition-transform md:object-contain duration-500 group-hover:scale-105" />
          ) : (
            <div className="flex h-full items-center justify-center text-sm text-muted-foreground">No image</div>
          )}
        </div>
        <div className="absolute right-3 top-3 flex gap-1 md:right-2 md:top-2">
          {discount > 0 && <span className="discount-badge rounded-full bg-sale px-2.5 py-1 text-[10px] font-medium text-sale-foreground md:rounded-full md:px-2 md:py-0.5 md:text-[10px] md:font-medium">-{discount}%</span>}
          {soldOut && <span className="rounded-sm bg-announce px-1.5 py-0.5 text-xs font-bold text-announce-foreground">Sold out</span>}
        </div>
      </Link>
        <div className="absolute inset-x-0 bottom-3 flex justify-center gap-2.5 transition-all duration-300 md:translate-y-4 md:opacity-0 md:group-hover:translate-y-0 md:group-hover:opacity-100 md:group-focus-within:translate-y-0 md:group-focus-within:opacity-100">
          <Button type="button" variant="ghost" size="icon" onClick={onWish} aria-label="Wishlist" title="Wishlist" className={`${actionBtn} hidden md:flex`}>
            <Heart className={`h-[18px] w-[18px] ${wished ? "fill-sale text-sale" : ""}`} />
          </Button>
          <Button type="button" variant="ghost" size="icon" onClick={() => setQuickView(true)} aria-label="Quick view" title="Quick view" className={actionBtn}>
            <Eye className="h-3.5 w-3.5 md:h-[18px] md:w-[18px]" />
          </Button>
        </div>
      </div>
      <Link to="/product/$handle" params={{ handle: p.handle }} className="mt-2 line-clamp-2 min-h-8 text-[11px] font-normal leading-snug md:mt-3 md:min-h-9 md:text-xs">
        {p.title}
      </Link>
      <div className="mobile-price md:mt-2 md:flex md:flex-wrap md:items-baseline md:gap-x-2 md:text-xs">
        {discount > 0 && compare && <span className="text-muted-foreground line-through">Rs. {rs(compare.amount)}</span>}
        <span className="font-semibold text-catalog-sale"><span className="md:hidden">{mobileFramed ? "Rs." : "RS."}</span><span className="hidden md:inline">{framed ? "Rs." : "RS."}</span> {rs(price.amount)}</span>
      </div>
      {soldOut ? (
        <Button asChild variant="outline" size="sm" className="mt-3 rounded-sm">
          <Link to="/product/$handle" params={{ handle: p.handle }}>View product</Link>
        </Button>
      ) : (
        <Button onClick={() => handleAdd()} disabled={isLoading} variant="outline" className="mt-2 h-8 w-full rounded-full px-1 text-[9px] font-semibold uppercase md:mt-3 md:h-9 md:border-catalog-border md:text-[10px] md:hover:bg-primary md:hover:text-primary-foreground" size="sm">
          {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : mobileQuickAdd ? <><span className="md:hidden">Quick add</span><span className="hidden md:inline">Add to cart</span></> : "Add to cart"}
        </Button>
      )}
      <Dialog open={quickView} onOpenChange={(o) => { setQuickView(o); if (o) { setQty(1); setImgIdx(0); } }}>
        <DialogContent className="max-h-[92dvh] w-[94vw] max-w-3xl gap-0 overflow-y-auto rounded-xl p-0 md:max-h-none md:w-full md:max-w-[900px] md:overflow-hidden md:rounded-none">
          <div className="grid md:grid-cols-2">
            <div>
            <div className="relative aspect-square bg-muted">
              {images[imgIdx] && <img key={imgIdx} src={images[imgIdx].url} alt={images[imgIdx].altText ?? p.title} className="h-full w-full object-cover" />}
              {images.length > 1 && (
                <>
                  <button type="button" aria-label="Previous image" onClick={() => setImgIdx((i) => (i - 1 + images.length) % images.length)} className="absolute left-3 top-1/2 flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-full bg-background shadow-md"><ChevronLeft className="h-4 w-4" /></button>
                  <button type="button" aria-label="Next image" onClick={() => setImgIdx((i) => (i + 1) % images.length)} className="absolute right-3 top-1/2 flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-full bg-background shadow-md"><ChevronRight className="h-4 w-4" /></button>
                </>
              )}
            </div>
            {images.length > 1 && (
              <div className="flex gap-1.5 overflow-x-auto p-1.5 md:hidden">
                {images.map((im, i) => (
                  <button key={im.url} type="button" aria-label={`Image ${i + 1}`} onClick={() => setImgIdx(i)} className={`aspect-square w-[32%] shrink-0 overflow-hidden rounded-md border-2 ${i === imgIdx ? "border-foreground" : "border-transparent"}`}>
                    <img src={im.url} alt="" className="h-full w-full object-cover" />
                  </button>
                ))}
              </div>
            )}
            </div>
            <div className="flex flex-col p-4 md:p-8">
              <DialogTitle className="pr-6 text-base font-medium leading-snug md:text-2xl">{p.title}</DialogTitle>
              <div className="mt-4 flex flex-wrap items-center gap-3">
                <span className="text-xl font-semibold text-catalog-sale">Rs. {rs(price.amount)}</span>
                {discount > 0 && compare && <span className="text-base text-muted-foreground line-through">Rs. {rs(compare.amount)}</span>}
                {discount > 0 && <span className="rounded-full bg-sale px-2.5 py-0.5 text-xs font-semibold text-sale-foreground">{discount}% OFF</span>}
              </div>
              <DialogDescription className="mt-4 line-clamp-4 text-sm text-muted-foreground">{p.description || "Wholesale pricing on everyday essentials."}</DialogDescription>
              {soldOut && <p className="mt-3 text-xs font-semibold text-destructive">Out of stock</p>}
              <p className="mt-5 text-sm font-medium">Quantity</p>
              <div className="mt-2 flex h-10 w-28 items-center justify-between rounded-full bg-muted px-3">
                <button type="button" aria-label="Decrease quantity" onClick={() => setQty((q) => Math.max(1, q - 1))}><Minus className="h-4 w-4" /></button>
                <span className="text-sm font-medium">{qty}</span>
                <button type="button" aria-label="Increase quantity" onClick={() => setQty((q) => q + 1)}><Plus className="h-4 w-4" /></button>
              </div>
              <div className="mt-6 flex gap-2">
                <Button variant="outline" onClick={async () => { await handleAdd(qty); setQuickView(false); }} disabled={isLoading || soldOut} className="h-11 flex-1 rounded-full border-foreground text-sm font-medium">
                  {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : `Add to cart – Rs. ${rs((parseFloat(price.amount) * qty).toFixed(2))}`}
                </Button>
                <Button type="button" variant="outline" size="icon" onClick={onWish} aria-label="Wishlist" className="h-11 w-11 rounded-full"><Heart className={`h-4 w-4 ${wished ? "fill-sale text-sale" : ""}`} /></Button>
              </div>
              <Button onClick={async () => { await handleAdd(qty); const url = useCartStore.getState().getCheckoutUrl(); if (url) window.open(url, "_blank"); }} disabled={isLoading || soldOut} className="mt-3 h-11 w-full rounded-full bg-sale text-sm font-semibold uppercase text-sale-foreground hover:bg-sale/90">
                Buy it now
              </Button>
              <Link to="/product/$handle" params={{ handle: p.handle }} onClick={() => setQuickView(false)} className="mt-5 inline-flex w-fit items-center gap-1 border-b border-foreground pb-0.5 text-sm font-medium hover:text-sale">View product details <ArrowUpRight className="h-3.5 w-3.5" /></Link>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

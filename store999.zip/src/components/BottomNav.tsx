import { useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { Heart, LayoutGrid, Search, ShoppingBag, User } from "lucide-react";
import { toast } from "sonner";
import { useCartStore } from "@/stores/cartStore";
import { Button } from "@/components/ui/button";
import { CartSheet } from "@/components/CartDrawer";

export function BottomNav() {
  const [cartOpen, setCartOpen] = useState(false);
  const totalItems = useCartStore((s) => s.items.reduce((sum, i) => sum + i.quantity, 0));
  const navigate = useNavigate();

  const comingSoon = (label: string) => toast(`${label} coming soon!`, { position: "top-center" });

  const openSearch = () => {
    navigate({ to: "/" });
    window.scrollTo({ top: 0 });
    window.dispatchEvent(new CustomEvent("bb:open-search"));
  };

  const item = "flex flex-col items-center justify-center h-14 min-w-0 gap-1 rounded-none px-0 py-2 text-[10px] font-normal text-foreground";

  return (
    <nav aria-label="Mobile navigation" className="fixed inset-x-0 bottom-0 z-40 border-t bg-background pb-[env(safe-area-inset-bottom)] md:hidden">
      <div className="grid grid-cols-5">
        <Link to="/" className={item}>
          <LayoutGrid className="h-5 w-5" />
          Shop
        </Link>
        <Button variant="ghost" className={item} onClick={() => comingSoon("Wishlist")}>
          <Heart className="h-5 w-5" />
          Wishlist
        </Button>
        <Button variant="ghost" className={item} onClick={() => setCartOpen(true)} aria-label="Open cart">
          <span className="relative">
            <ShoppingBag className="h-5 w-5" />
            {totalItems > 0 && (
              <span className="absolute -right-2 -top-1.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-sale px-1 text-[10px] text-sale-foreground">
                {totalItems}
              </span>
            )}
          </span>
          Cart
        </Button>
        <Button variant="ghost" className={item} onClick={() => comingSoon("Account")}>
          <User className="h-5 w-5" />
          Account
        </Button>
        <Button variant="ghost" className={item} onClick={openSearch}>
          <Search className="h-5 w-5" />
          Search
        </Button>
      </div>
      <CartSheet open={cartOpen} onOpenChange={setCartOpen} />
    </nav>
  );
}

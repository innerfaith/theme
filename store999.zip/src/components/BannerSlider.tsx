import { useCallback, useEffect, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { ChevronLeft, ChevronRight } from "lucide-react";

export type Slide = { src: string; alt: string; slug: string };

export function BannerSlider({ slides, aspect, interval = 4500 }: { slides: Slide[]; aspect: string; interval?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(0);
  const [paused, setPaused] = useState(false);
  const go = useCallback((i: number) => {
    const el = ref.current;
    if (!el) return;
    const n = (i + slides.length) % slides.length;
    el.scrollTo({ left: n * el.clientWidth, behavior: "smooth" });
  }, [slides.length]);

  useEffect(() => {
    if (paused || slides.length < 2) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const t = window.setInterval(() => go(active + 1), interval);
    return () => window.clearInterval(t);
  }, [active, paused, go, interval, slides.length]);

  return (
    <div className="banner-slider group relative" onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)} onTouchStart={() => setPaused(true)} onTouchEnd={() => setPaused(false)} onFocus={() => setPaused(true)} onBlur={() => setPaused(false)} aria-roledescription="carousel">
      <div
        ref={ref}
        onScroll={(e) => setActive(Math.round(e.currentTarget.scrollLeft / e.currentTarget.clientWidth))}
        className="flex snap-x snap-mandatory overflow-x-auto [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
      >
        {slides.map((s, i) => (
          <Link key={s.src} to="/collections/$slug" params={{ slug: s.slug }} aria-label={s.alt} className="block w-full shrink-0 snap-start overflow-hidden" aria-hidden={i !== active} tabIndex={i === active ? 0 : -1}>
            <img src={s.src} alt={s.alt} loading={i === 0 ? "eager" : "lazy"} className={`banner-slide w-full object-cover ${aspect} ${i === active ? "is-active" : ""}`} />
          </Link>
        ))}
      </div>
      {slides.length > 1 && <>
        <button type="button" aria-label="Previous slide" onClick={() => go(active - 1)} className="absolute left-3 top-1/2 hidden h-10 w-10 -translate-y-1/2 items-center justify-center rounded-full bg-background/90 opacity-0 shadow-md transition-opacity duration-300 group-hover:opacity-100 focus-visible:opacity-100 md:flex"><ChevronLeft className="h-5 w-5" /></button>
        <button type="button" aria-label="Next slide" onClick={() => go(active + 1)} className="absolute right-3 top-1/2 hidden h-10 w-10 -translate-y-1/2 items-center justify-center rounded-full bg-background/90 opacity-0 shadow-md transition-opacity duration-300 group-hover:opacity-100 focus-visible:opacity-100 md:flex"><ChevronRight className="h-5 w-5" /></button>
        <div className="absolute bottom-3 left-1/2 flex -translate-x-1/2 items-center gap-2 rounded-full bg-background/70 px-3 py-1.5 backdrop-blur-sm md:bottom-4">
          {slides.map((_, i) => (
            <button key={i} type="button" aria-label={`Slide ${i + 1}`} aria-current={i === active} onClick={() => go(i)} className="relative h-1.5 overflow-hidden rounded-full bg-foreground/30 transition-all duration-500" style={{ width: i === active ? 28 : 6 }}>
              {i === active && <span key={`${active}-${paused}`} className={`absolute inset-y-0 left-0 rounded-full bg-foreground ${paused ? "w-full" : "banner-progress"}`} style={{ animationDuration: `${interval}ms` }} />}
            </button>
          ))}
        </div>
      </>}
    </div>
  );
}

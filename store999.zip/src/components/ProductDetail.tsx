import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ProductCard } from "@/components/ProductCard";
import { fetchProducts } from "@/lib/shopify";
import { Link } from "@tanstack/react-router";
import { ArrowUpRight, Check, Package, RotateCcw, ShieldCheck, Truck, ChevronLeft, ChevronRight, Heart, Loader2, Maximize2, Minus, Plus, Share2, ShoppingBag } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { formatPrice, type ShopifyProduct } from "@/lib/shopify";
import { useCartStore } from "@/stores/cartStore";
import { useWishlistStore } from "@/stores/wishlistStore";

export function ProductDetail({ product }: { product: ShopifyProduct }) {
  const p = product.node;
  const images = p.images.edges.map((edge) => edge.node);
  const variants = p.variants.edges.map((edge) => edge.node);
  const [variantIdx, setVariantIdx] = useState(0);
  const [imageIdx, setImageIdx] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [zoom, setZoom] = useState(false);
  const [added, setAdded] = useState(false);
  const [hydrated, setHydrated] = useState(false);
  useEffect(() => setHydrated(true), []);
  const [showBar, setShowBar] = useState(false);
  useEffect(() => {
    const el = document.getElementById("main-add-to-cart");
    if (!el) return;
    const io = new IntersectionObserver(([e]) => e && setShowBar(!e.isIntersecting && e.boundingClientRect.top < 0));
    io.observe(el);
    return () => io.disconnect();
  }, []);
  const wished = useWishlistStore((state) => state.handles.includes(p.handle)) && hydrated;
  const toggleWish = useWishlistStore((state) => state.toggle);
  const addItem = useCartStore((state) => state.addItem);
  const isLoading = useCartStore((state) => state.isLoading);
  const variant = variants[variantIdx];
  const image = images[imageIdx];
  const price = variant?.price ?? p.priceRange.minVariantPrice;
  const compare = variant?.compareAtPrice;
  const saving = compare ? Math.max(0, Number(compare.amount) - Number(price.amount)) : 0;
  const discount = compare && saving > 0 ? Math.round(saving / Number(compare.amount) * 100) : 0;
  const money = (amount: number | string) => formatPrice(String(amount), price.currencyCode);
  const moveImage = (direction: number) => setImageIdx((current) => (current + direction + images.length) % images.length);

  const handleAdd = async () => {
    if (!variant || !variant.availableForSale) return;
    const before = useCartStore.getState().items.find((item) => item.variantId === variant.id)?.quantity ?? 0;
    await addItem({ product, variantId: variant.id, variantTitle: variant.title, price: variant.price, quantity, selectedOptions: variant.selectedOptions || [] });
    const after = useCartStore.getState().items.find((item) => item.variantId === variant.id)?.quantity ?? 0;
    if (after >= before + quantity) {
      setAdded(true);
      toast.success(`${quantity} × ${p.title} added to cart`);
    } else {
      toast.error("Couldn't add to cart. Please try again.");
    }
  };
  const { data: allProducts = [] } = useQuery({ queryKey: ["products"], queryFn: () => fetchProducts(250) });
  const related = allProducts.filter((x) => x.node.handle !== p.handle).slice(0, 4);
  const [tab, setTab] = useState<"description" | "returns" | "info">("description");
  const lineTotal = Number(price.amount) * quantity;
  const COD = 299, FREE = 495;
  const progress = Math.min(100, (lineTotal / FREE) * 100);
  const share = async () => {
    try {
      if (navigator.share) await navigator.share({ title: p.title, url: window.location.href });
      else { await navigator.clipboard.writeText(window.location.href); toast.success("Product link copied"); }
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") return;
      toast.error("Couldn't share this product link.");
    }
  };

  return (
    <>
      <Dialog open={zoom} onOpenChange={setZoom}>
        <DialogContent className="max-w-4xl p-4 md:p-6"><DialogTitle className="pr-8 text-sm font-medium">{p.title}</DialogTitle>
          {image && <img src={image.url} alt={image.altText ?? p.title} className="max-h-[65dvh] w-full object-contain" />}
          {images.length > 1 && <div className="flex items-center justify-center gap-5"><Button variant="outline" size="icon" aria-label="Previous enlarged photo" onClick={() => moveImage(-1)}><ChevronLeft /></Button><span className="text-xs tabular-nums">{imageIdx + 1} / {images.length}</span><Button variant="outline" size="icon" aria-label="Next enlarged photo" onClick={() => moveImage(1)}><ChevronRight /></Button></div>}
        </DialogContent>
      </Dialog>

    <main className="product-detail-desktop mx-auto max-w-6xl px-3 pb-36 pt-4 md:px-6 md:pb-28 md:pt-6">
      <nav aria-label="Breadcrumb" className="mb-4 flex min-w-0 items-center gap-2 text-[11px] md:mb-6 text-muted-foreground">
        <Link to="/" className="shrink-0 hover:text-sale">Home</Link><ChevronRight className="h-3 w-3 shrink-0" /><span className="truncate">{p.title}</span>
      </nav>
      <div className="grid items-start gap-4 md:grid-cols-[1fr_1fr] md:gap-8 lg:gap-12">
        <section aria-label="Product gallery" className="flex min-w-0 flex-col-reverse gap-2 md:sticky md:top-24 md:flex-row md:gap-3">
          <div className="flex shrink-0 gap-2 overflow-x-auto md:w-14 md:flex-col lg:w-16">
            {images.map((img, i) => <button key={img.url} type="button" onClick={() => setImageIdx(i)} aria-label={`View photo ${i + 1}`} className={`aspect-square w-[23%] shrink-0 overflow-hidden rounded border-2 md:w-auto ${i === imageIdx ? "border-sale" : "border-border"}`}><img src={img.url} alt="" className="h-full w-full object-cover" /></button>)}
          </div>
          <div className="relative aspect-square min-w-0 flex-1 overflow-hidden rounded border border-border bg-muted/40">
            {image ? <button type="button" onClick={() => setZoom(true)} aria-label="Enlarge product photo" className="h-full w-full"><img key={image.url} src={image.url} alt={image.altText ?? p.title} className="product-gallery-image h-full w-full object-cover" /></button> : <div className="flex h-full items-center justify-center text-muted-foreground">No image available</div>}
            {images.length > 1 && <>
              <button type="button" aria-label="Previous photo" onClick={() => moveImage(-1)} className="absolute left-3 top-1/2 flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-full bg-background shadow"><ChevronLeft className="h-4 w-4" /></button>
              <button type="button" aria-label="Next photo" onClick={() => moveImage(1)} className="absolute right-3 top-1/2 flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-full bg-background shadow"><ChevronRight className="h-4 w-4" /></button>
            </>}
          </div>
        </section>
        <section aria-label="Product information" className="min-w-0">
          <h1 className="text-base font-normal leading-snug md:text-xl lg:text-2xl">{p.title}</h1>
          <div className="mt-4 flex flex-wrap items-center gap-3">
            <span className="text-xl font-medium tabular-nums text-catalog-sale">Rs. {Number(price.amount).toFixed(2)}</span>
            {saving > 0 && compare && <span className="text-sm text-muted-foreground line-through">Rs. {Number(compare.amount).toFixed(2)}</span>}
            {discount > 0 && <span className="rounded-full bg-sale px-2.5 py-0.5 text-[11px] font-semibold text-sale-foreground">{discount}% OFF</span>}
          </div>
          {variants.length > 1 && <div className="mt-5 flex flex-wrap gap-2">{variants.map((v, i) => <Button key={v.id} size="sm" variant={i === variantIdx ? "default" : "outline"} onClick={() => { setVariantIdx(i); setAdded(false); }} className="rounded-full">{v.title}</Button>)}</div>}
          <p className="mt-5 text-xs font-medium">Quantity</p>
          <div className="mt-2 flex h-9 w-28 items-center justify-between rounded-full bg-muted px-3">
            <button type="button" aria-label="Decrease quantity" disabled={quantity <= 1} onClick={() => setQuantity((q) => Math.max(1, q - 1))}><Minus className="h-3.5 w-3.5" /></button>
            <span className="text-sm tabular-nums">{quantity}</span>
            <button type="button" aria-label="Increase quantity" onClick={() => setQuantity((q) => q + 1)}><Plus className="h-3.5 w-3.5" /></button>
          </div>
          <p className="mt-5 flex items-center gap-2 text-xs"><span className={`h-2 w-2 rounded-full ${variant?.availableForSale ? "bg-product-available" : "bg-muted-foreground"}`} />{variant?.availableForSale ? "In stock" : "Sold out"}</p>
          <div className={`mt-2 h-1 rounded-full ${variant?.availableForSale ? "bg-product-available" : "bg-muted"}`} />
          <div className="mt-6 rounded border border-border p-4">
            <p className="text-center text-xs">{lineTotal >= FREE ? "You get Free Shipping!" : lineTotal >= COD ? `Spend ₹${Math.ceil(FREE - lineTotal)} more to get Free Shipping` : `Spend ₹${Math.ceil(COD - lineTotal)} more to get Cash on Delivery (COD)`}</p>
            <div className="relative mt-6 h-2 rounded-full bg-muted">
              <div className="h-full rounded-full bg-foreground transition-all duration-500" style={{ width: `${progress}%` }} />
              <span className="absolute -top-5 -translate-x-1/2 text-[10px]" style={{ left: `${(COD / FREE) * 100}%` }}>₹{COD}</span>
              <span className="absolute -top-5 right-0 text-[10px]">₹{FREE}</span>
            </div>
            <div className="mt-2 flex justify-between text-[10px] text-muted-foreground"><span /><span className="-translate-x-1/2" style={{ marginLeft: `${(COD / FREE) * 100}%` }}>Cash on Delivery (COD)</span><span className="ml-auto">Free Shipping</span></div>
          </div>
          <div className="mt-5 flex gap-2">
            <Button id="main-add-to-cart" variant="outline" onClick={handleAdd} disabled={isLoading || !variant?.availableForSale} className="h-11 flex-1 rounded-full border-foreground text-xs font-medium">
              {isLoading ? <Loader2 className="animate-spin" /> : !variant?.availableForSale ? "Sold out" : added ? <><Check /> Added to cart</> : `Add to cart – Rs. ${lineTotal.toFixed(2)}`}
            </Button>
            <Button variant="outline" size="icon" onClick={() => { const saved = toggleWish(p.handle); toast.success(saved ? "Added to wishlist" : "Removed from wishlist"); }} aria-label="Wishlist" aria-pressed={wished} className="h-11 w-11 rounded-full"><Heart className={wished ? "fill-sale text-sale" : ""} /></Button>
          </div>
          <button type="button" onClick={share} className="mt-4 inline-flex items-center gap-1.5 text-xs hover:text-sale"><Share2 className="h-3.5 w-3.5" /> Share</button>
          <div className="mt-5 grid gap-3 md:grid-cols-2">
            <div className="flex flex-col items-center gap-2 border border-foreground p-5 text-center text-[11px]"><Truck className="h-5 w-5" /><span>Estimate Dispatch time – <b>Within 48 hours.</b></span></div>
            <div className="flex flex-col items-center gap-2 border border-foreground p-5 text-center text-[11px]"><RotateCcw className="h-5 w-5" /><span>Return within <b>3 days</b> of purchase. Check out our easy return policies</span></div>
          </div>
          <div className="mt-5 flex flex-wrap items-center gap-3 text-[10px]">
            <span className="flex items-center gap-1.5"><ShieldCheck className="h-4 w-4" />Guaranteed Safe Checkout</span>
            {["VISA", "PayPal", "Mastercard", "AMEX", "UPI"].map((m) => <span key={m} className="rounded border border-border px-2 py-1 font-semibold">{m}</span>)}
          </div>
        </section>
      </div>
      <div className="mt-10 grid gap-3 md:mt-14 md:grid-cols-[180px_1fr] md:gap-6">
        <div className="flex overflow-x-auto md:flex-col">
          {([["description", "Description"], ["returns", "Return Policies"], ["info", "Additional Information"]] as const).map(([k, l]) => <button key={k} type="button" onClick={() => setTab(k)} className={`shrink-0 border-b-2 px-2 py-2 text-left text-xs md:border-b-0 md:border-l-2 md:px-3 md:py-2.5 ${tab === k ? "border-foreground font-medium" : "border-transparent text-muted-foreground hover:text-foreground"}`}>{l}</button>)}
        </div>
        <div className="min-h-40 rounded border border-border p-5 text-xs leading-relaxed text-muted-foreground">
          {tab === "description" && <><p className="mb-3 font-medium text-foreground">Product Description</p><p className="whitespace-pre-line">{p.description || "No additional product description is available."}</p></>}
          {tab === "returns" && <><p className="mb-3 font-medium text-foreground">Return Policies</p><p>Returns are accepted within 3 days of purchase for unused items in original packaging.</p></>}
          {tab === "info" && <dl className="space-y-2"><div className="flex gap-6"><dt className="w-28 text-foreground">Product</dt><dd>{p.title}</dd></div>{variant?.selectedOptions.filter((o) => o.value !== "Default Title").map((o) => <div key={o.name} className="flex gap-6"><dt className="w-28 text-foreground">{o.name}</dt><dd>{o.value}</dd></div>)}<div className="flex gap-6"><dt className="w-28 text-foreground">Availability</dt><dd>{variant?.availableForSale ? "In stock" : "Sold out"}</dd></div></dl>}
        </div>
      </div>
      {related.length > 0 && <section className="mt-10 md:mt-14">
        <h2 className="mb-5 text-center text-xl md:mb-7 md:text-2xl font-normal text-sale lg:text-3xl">People Also Bought</h2>
        <div className="grid grid-cols-2 gap-2 md:grid-cols-4 md:gap-4">{related.map((r) => <ProductCard key={r.node.id} product={r} />)}</div>
      </section>}
      <div aria-hidden={!showBar} className={`fixed inset-x-0 bottom-0 z-30 border-t max-md:bottom-14 border-border bg-background transition-all duration-300 ease-out ${showBar ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-full opacity-0"}`}>
        <div className="mx-auto flex max-w-6xl items-center gap-2 px-3 py-2 md:gap-4 md:px-6 md:py-2.5">
          {images[0] && <img src={images[0].url} alt="" className="hidden h-11 w-11 rounded object-cover md:block" />}
          <p className="hidden min-w-0 flex-1 truncate text-xs md:block">{p.title}</p>
          <span className="text-xs tabular-nums max-md:hidden">Rs. {Number(price.amount).toFixed(2)}</span>
          <div className="flex h-8 w-24 items-center justify-between rounded-full border border-border px-2.5">
            <button type="button" aria-label="Decrease quantity" onClick={() => setQuantity((q) => Math.max(1, q - 1))}><Minus className="h-3 w-3" /></button>
            <span className="text-xs tabular-nums">{quantity}</span>
            <button type="button" aria-label="Increase quantity" onClick={() => setQuantity((q) => q + 1)}><Plus className="h-3 w-3" /></button>
          </div>
          <Button variant="outline" onClick={handleAdd} disabled={isLoading || !variant?.availableForSale} className="h-9 flex-1 rounded-full border-foreground px-7 text-xs md:flex-none">{isLoading ? <Loader2 className="animate-spin" /> : "Add to cart"}</Button>
        </div>
      </div>
    </main>
    </>
  );
}
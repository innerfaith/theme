import { create } from "zustand";
import { persist } from "zustand/middleware";

interface WishlistState {
  handles: string[];
  toggle: (handle: string) => boolean;
  has: (handle: string) => boolean;
}

export const useWishlistStore = create<WishlistState>()(
  persist(
    (set, get) => ({
      handles: [],
      toggle: (handle) => {
        const added = !get().handles.includes(handle);
        set({ handles: added ? [...get().handles, handle] : get().handles.filter((h) => h !== handle) });
        return added;
      },
      has: (handle) => get().handles.includes(handle),
    }),
    { name: "wishlist" },
  ),
);

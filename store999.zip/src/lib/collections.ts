import type { ShopifyProduct } from "@/lib/shopify";
import desktopCategory0 from "@/assets/desktop-category-0.jpg";
import desktopCategory1 from "@/assets/desktop-category-1.jpg";
import desktopCategory2 from "@/assets/desktop-category-2.jpg";
import desktopCategory3 from "@/assets/desktop-category-3.jpg";
import desktopCategory4 from "@/assets/desktop-category-4.jpg";
import desktopCategory5 from "@/assets/desktop-category-5.jpg";
import desktopCategory7 from "@/assets/desktop-category-7.jpg";
import c1 from "@/assets/mobile-reference-category-1.png.asset.json";
import c2 from "@/assets/mobile-reference-category-2.png.asset.json";
import c4 from "@/assets/mobile-reference-category-4.png.asset.json";
import c5 from "@/assets/mobile-reference-category-5.png.asset.json";
import c7 from "@/assets/mobile-reference-category-7.png.asset.json";
import c8 from "@/assets/mobile-reference-category-8.png.asset.json";
import c9 from "@/assets/mobile-reference-category-9.png.asset.json";
import c10 from "@/assets/mobile-reference-category-10.png.asset.json";
import c11 from "@/assets/mobile-reference-category-11.png.asset.json";

export interface Collection {
  slug: string;
  label: string;
  image: string;
  /** Returns products for this collection from the full store list. */
  select: (all: ShopifyProduct[]) => ShopifyProduct[];
}

const byTitle = (re: RegExp) => (all: ShopifyProduct[]) => all.filter((p) => re.test(p.node.title));
const isDiscounted = (p: ShopifyProduct) => {
  const v = p.node.variants.edges[0]?.node;
  return !!v?.compareAtPrice && parseFloat(v.compareAtPrice.amount) > parseFloat(v.price.amount);
};

export const COLLECTIONS: Collection[] = [
  { slug: "personalized-gifts", label: "Personalized Gifts", image: desktopCategory4, select: byTitle(/personalized|custom/i) },
  { slug: "under-99", label: "Deals Under ₹99", image: desktopCategory2, select: (all) => all.filter((p) => Number(p.node.priceRange.minVariantPrice.amount) <= 99) },
  { slug: "new-arrivals", label: "New Arrivals", image: desktopCategory0, select: (all) => all },
  { slug: "summer-collection", label: "Summer Collection", image: c5.url, select: byTitle(/bottle|tote|socks|hair|mug/i) },
  { slug: "trending-products", label: "Trending Products", image: desktopCategory3, select: (all) => all.filter((_, i) => i % 2 === 0) },
  { slug: "electronic-gadgets", label: "Electronic Gadgets", image: desktopCategory5, select: byTitle(/usb|cable|phone/i) },
  { slug: "on-sale", label: "On Sale", image: desktopCategory2, select: (all) => all.filter(isDiscounted) },
  { slug: "home", label: "Home", image: c1.url, select: byTitle(/brush|sponge|container|mug|bottle|dish|scissors|tape/i) },
  { slug: "kitchen", label: "Kitchen", image: c2.url, select: byTitle(/lunch|container|dish|teaspoon|mug|sponge|bottle/i) },
  { slug: "automotives", label: "Automotives", image: c9.url, select: byTitle(/phone stand|keyring|usb/i) },
  { slug: "electronics", label: "Electronics", image: c4.url, select: byTitle(/usb|cable|phone/i) },
  { slug: "accessories", label: "Accessories", image: c10.url, select: byTitle(/keyring|hair|socks|tote|pouch/i) },
  { slug: "for-women", label: "For Women", image: desktopCategory7, select: byTitle(/hair|tote|pouch|socks/i) },
  { slug: "bags-luggage", label: "Bags & Luggage", image: c11.url, select: byTitle(/tote|pouch/i) },
  { slug: "gadgets-tools", label: "Gadgets & Tools", image: c9.url, select: byTitle(/scissors|tape|ruler|phone|usb/i) },
  { slug: "storage-organizers", label: "Storage & Organizers", image: c7.url, select: byTitle(/container|pouch|box/i) },
  { slug: "office-stationery", label: "Office & Stationery", image: c8.url, select: byTitle(/notebook|pen|scissors|tape|ruler/i) },
  { slug: "travel", label: "Travel", image: c11.url, select: byTitle(/bottle|pouch|tote|keyring/i) },
  { slug: "for-men", label: "For Men", image: c10.url, select: byTitle(/socks|keyring|bottle|phone|usb/i) },
  { slug: "health-personal-care", label: "Health & Personal Care", image: desktopCategory7, select: byTitle(/comb|hair|sponge|brush/i) },
  { slug: "kids-baby", label: "Kids & Baby Products", image: c5.url, select: byTitle(/bottle|lunch|notebook|pen|ruler/i) },
  { slug: "decor-lights-gift", label: "Decor, Lights, Gift", image: c9.url, select: byTitle(/mug|keyring|tote|notebook/i) },
  { slug: "sports-fitness", label: "Sports & Fitness", image: c11.url, select: byTitle(/bottle|socks|tote/i) },
  { slug: "toys-games", label: "Toys & Games", image: desktopCategory3, select: (all) => all.filter((_, i) => i % 4 === 1) },
  { slug: "jewellery", label: "Jewellery", image: c10.url, select: byTitle(/hair clip|keyring|pouch/i) },
  { slug: "premium", label: "199+ Premium", image: desktopCategory1, select: (all) => all.filter((p) => parseFloat(p.node.priceRange.minVariantPrice.amount) > 199) },
  { slug: "best-sellers", label: "Best Sellers", image: desktopCategory1, select: (all) => all.filter((_, i) => i % 3 === 0) },
  { slug: "home-kitchen", label: "Home & Kitchen", image: desktopCategory4, select: byTitle(/lunch|container|dish|teaspoon|mug|sponge|bottle|brush/i) },
];

export const MENU_GROUPS: Record<string, { label: string; slug?: string; max?: number }[]> = {
  "Shop by Collection": ["home", "kitchen", "accessories", "for-women", "for-men", "travel", "bags-luggage", "health-personal-care", "kids-baby", "office-stationery"].map((slug) => ({ slug, label: COLLECTIONS.find((c) => c.slug === slug)!.label })),
  "Shop by Price": [...[29, 49, 99, 149, 199].map((n) => ({ label: `Under ${n}`, max: n })), { label: "199+ Premium", slug: "premium" }],
  "Shop by Industry": ["decor-lights-gift", "storage-organizers", "gadgets-tools", "sports-fitness", "toys-games", "automotives", "electronics", "jewellery"].map((slug) => ({ slug, label: COLLECTIONS.find((c) => c.slug === slug)!.label })),
};

export const findCollection = (slug: string) => COLLECTIONS.find((c) => c.slug === slug);

/** Maps menu / category labels to collection slugs. */
const LABEL_TO_SLUG: Record<string, string> = {
  "Trending Gadgets": "trending-products",
  Trending: "trending-products",
  "Home Items": "home",
  "Mugs & Bottles": "kitchen",
  Customize: "office-stationery",
  "Hangers & Shelves": "storage-organizers",
  "Customized Gift": "accessories",
  "Health & Personal Care": "for-women",
  "On sale": "on-sale",
};
export const slugFor = (label: string) =>
  LABEL_TO_SLUG[label] ?? COLLECTIONS.find((c) => c.label.toLowerCase() === label.toLowerCase())?.slug ?? "new-arrivals";

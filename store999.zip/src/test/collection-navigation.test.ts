import { describe, expect, it } from "vitest";
import { findCollection } from "@/lib/collections";
import type { ShopifyProduct } from "@/lib/shopify";

const product = (title: string, amount: number): ShopifyProduct => ({ node: {
  id: title, title, handle: title, description: "", options: [],
  images: { edges: [] }, variants: { edges: [] },
  priceRange: { minVariantPrice: { amount: String(amount), currencyCode: "INR" } },
} });

describe("Home section collection destinations", () => {
  it("keeps the ₹99 collection within its displayed budget", () => {
    const rows = [product("A", 98), product("B", 99), product("C", 100)];
    expect(findCollection("under-99")?.select(rows).map((p) => p.node.title)).toEqual(["A", "B"]);
  });
  it("shows only matching store products in personalized gifts", () => {
    const rows = [product("Custom mug", 50), product("Personalized notebook", 60), product("USB cable", 40)];
    expect(findCollection("personalized-gifts")?.select(rows).map((p) => p.node.title)).toEqual(["Custom mug", "Personalized notebook"]);
  });
});
import { createFileRoute, Link } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { ChevronRight } from "lucide-react";
import { fetchProducts } from "@/lib/shopify";
import { COLLECTIONS } from "@/lib/collections";

const productsQuery = queryOptions({ queryKey: ["products"], queryFn: () => fetchProducts(250) });

export const Route = createFileRoute("/collections/")({
  loader: ({ context }) => context.queryClient.ensureQueryData(productsQuery),
  head: () => ({
    meta: [
      { title: "All Collections – BulkBazaar" },
      { name: "description", content: "Browse every BulkBazaar collection: new arrivals, gadgets, home, kitchen, travel and more." },
      { property: "og:title", content: "All Collections – BulkBazaar" },
      { property: "og:description", content: "Browse every BulkBazaar wholesale collection." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AllCollections,
});

function AllCollections() {
  const { data: all } = useSuspenseQuery(productsQuery);
  return (
    <main>
      <section className="px-4 pb-8 pt-10 text-center md:pb-12 md:pt-16">
        <h1 className="text-4xl font-normal md:text-6xl">All Collections</h1>
        <nav aria-label="Breadcrumb" className="mt-4 flex items-center justify-center gap-3 text-sm">
          <Link to="/" className="hover:text-sale">Home</Link><ChevronRight className="h-3.5 w-3.5" /><span className="text-muted-foreground">Collections</span>
        </nav>
      </section>
      <div className="mx-auto grid max-w-7xl grid-cols-2 gap-4 px-4 pb-16 sm:grid-cols-3 lg:grid-cols-4 lg:gap-6">
        {COLLECTIONS.map((c) => (
          <Link data-store-reveal key={c.slug} to="/collections/$slug" params={{ slug: c.slug }} className="group overflow-hidden rounded-xl border bg-card transition-shadow hover:shadow-lg">
            <div className="aspect-square overflow-hidden bg-muted">
              <img src={c.image} alt={c.label} loading="lazy" className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
            </div>
            <div className="flex items-center justify-between gap-2 px-4 py-3">
              <div className="min-w-0">
                <p className="truncate text-sm font-semibold group-hover:text-sale">{c.label}</p>
                <p className="text-xs text-muted-foreground">{c.select(all).length} products</p>
              </div>
              <ChevronRight className="h-4 w-4 shrink-0 transition-transform group-hover:translate-x-1" />
            </div>
          </Link>
        ))}
      </div>
    </main>
  );
}

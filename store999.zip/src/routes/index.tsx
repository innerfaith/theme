import { useRef, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { slugFor } from "@/lib/collections";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { ArrowUpRight, Zap } from "lucide-react";
import { fetchProducts, type ShopifyProduct } from "@/lib/shopify";
import { ProductCard } from "@/components/ProductCard";
import budget0 from "@/assets/desktop-budget-0.jpg";
import budget1 from "@/assets/desktop-budget-1.jpg";
import budget2 from "@/assets/desktop-budget-2.jpg";
import budget3 from "@/assets/desktop-budget-3.jpg";
import budget4 from "@/assets/desktop-budget-4.jpg";
import budget5 from "@/assets/desktop-budget-5.jpg";
import { Button } from "@/components/ui/button";
import mobileBanner from "@/assets/mobile-reference-delivery.png.asset.json";
import mobileBudget0 from "@/assets/mobile-reference-budget-0.png.asset.json";
import mobileBudget1 from "@/assets/mobile-reference-budget-1.png.asset.json";
import mobileBudget2 from "@/assets/mobile-reference-budget-2.png.asset.json";
import mobileBudget3 from "@/assets/mobile-reference-budget-3.png.asset.json";
import mobileBudget4 from "@/assets/mobile-reference-budget-4.png.asset.json";
import mobileBudget5 from "@/assets/mobile-reference-budget-5.png.asset.json";
import desktopBanner from "@/assets/desktop-gadgets-banner.jpg";
import slideStarting from "@/assets/slide-starting-29.jpg";
import slideCod from "@/assets/slide-cod.jpg";
import { BannerSlider } from "@/components/BannerSlider";
const SLIDES = [
  { src: mobileBanner.url, alt: "Free Delivery on Orders Above ₹495", slug: "on-sale" },
  { src: desktopBanner, alt: "Smart Gadgets, Smarter Prices — Trending Products Live Now", slug: "on-sale" },
  { src: slideStarting, alt: "Products starting at ₹29 — Shop wholesale deals", slug: "under-99" },
  { src: slideCod, alt: "Cash on Delivery available on orders above ₹299", slug: "on-sale" },
];
const DESKTOP_SLIDES = [SLIDES[1], SLIDES[0], SLIDES[2], SLIDES[3]].filter((s): s is (typeof SLIDES)[number] => Boolean(s));
import desktopCategory0 from "@/assets/desktop-category-0.jpg";
import desktopCategory1 from "@/assets/desktop-category-1.jpg";
import desktopCategory2 from "@/assets/desktop-category-2.jpg";
import desktopCategory3 from "@/assets/desktop-category-3.jpg";
import desktopCategory4 from "@/assets/desktop-category-4.jpg";
import desktopCategory5 from "@/assets/desktop-category-5.jpg";
import desktopCategory6 from "@/assets/desktop-category-6.jpg";
import desktopCategory7 from "@/assets/desktop-category-7.jpg";
import category0 from "@/assets/mobile-reference-category-0.png.asset.json";
import category1 from "@/assets/mobile-reference-category-1.png.asset.json";
import category2 from "@/assets/mobile-reference-category-2.png.asset.json";
import category3 from "@/assets/mobile-reference-category-3.png.asset.json";
import category4 from "@/assets/mobile-reference-category-4.png.asset.json";
import category5 from "@/assets/mobile-reference-category-5.png.asset.json";
import category6 from "@/assets/mobile-reference-category-6.png.asset.json";
import category7 from "@/assets/mobile-reference-category-7.png.asset.json";
import category8 from "@/assets/mobile-reference-category-8.png.asset.json";
import category9 from "@/assets/mobile-reference-category-9.png.asset.json";
import category10 from "@/assets/mobile-reference-category-10.png.asset.json";
import category11 from "@/assets/mobile-reference-category-11.png.asset.json";

const MOBILE_CATEGORIES = [
  { label: "New Arrivals", image: category0.url },
  { label: "Home Items", image: category1.url },
  { label: "Kitchen", image: category2.url },
  { label: "Customize", image: category3.url },
  { label: "Electronic Gadgets", image: category4.url },
  { label: "Mugs & Bottles", image: category5.url },
  { label: "Trending", image: category6.url },
  { label: "Storage & Organizers", image: category7.url },
  { label: "Office & Stationery", image: category8.url },
  { label: "Hangers & Shelves", image: category9.url },
  { label: "Accessories", image: category10.url },
  { label: "Travel", image: category11.url },
];

const productsQuery = queryOptions({ queryKey: ["products"], queryFn: () => fetchProducts(250) });

const BUDGETS = [
  { label: "Under", price: 29, max: 29 },
  { label: "Under", price: 49, max: 49 },
  { label: "Under", price: 99, max: 99 },
  { label: "Under", price: 149, max: 149 },
  { label: "Under", price: 199, max: 199 },
  { label: "Premium", price: 99, max: Infinity },
];
const MOBILE_BUDGET_IMAGES = [mobileBudget0.url, mobileBudget1.url, mobileBudget2.url, mobileBudget3.url, mobileBudget4.url, mobileBudget5.url];
const BUDGET_IMAGES = [budget0, budget1, budget2, budget3, budget4, budget5];
const DESKTOP_CATEGORIES = [
  { label: "New Arrivals", image: desktopCategory0 },
  { label: "Best Sellers", image: desktopCategory1 },
  { label: "On Sale", image: desktopCategory2 },
  { label: "Trending Products", image: desktopCategory3 },
  { label: "Home & Kitchen", image: desktopCategory4 },
  { label: "Electronic Gadgets", image: desktopCategory5 },
  { label: "Customized Gift", image: desktopCategory6 },
  { label: "Health & Personal Care", image: desktopCategory7 },
];

export const Route = createFileRoute("/")({
  validateSearch: (s: Record<string, unknown>): { q?: string | undefined; max?: number | undefined } => ({
    q: typeof s["q"] === "string" ? (s["q"] as string) : undefined,
    max: typeof s["max"] === "number" ? (s["max"] as number) : undefined,
  }),
  head: () => ({
    meta: [
      { title: "BulkBazaar: Products starting from just Rs. 29" },
      { name: "description", content: "Wholesale prices on gadgets, home & kitchen, gifts, toys and more. Free shipping above Rs. 495, COD above Rs. 295." },
      { property: "og:title", content: "BulkBazaar: Products starting from just Rs. 29" },
      { property: "og:description", content: "Wholesale prices on gadgets, home & kitchen, gifts, toys and more." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(productsQuery),
  component: Index,
});

function Section({ title, products, id, desktopOnly = false, featured = false, sixColumns = false, more = false, moreSlug = "new-arrivals", mobileFeatured = false, mobileQuickAdd = false }: { title: string; products: ShopifyProduct[]; id?: string; desktopOnly?: boolean; featured?: boolean; sixColumns?: boolean; more?: boolean; moreSlug?: string; mobileFeatured?: boolean; mobileQuickAdd?: boolean }) {
  return (
    <section id={id} className={`mx-auto max-w-7xl scroll-mt-24 px-6 py-6 md:scroll-mt-40 md:px-4 md:py-8 ${desktopOnly ? "hidden md:block" : ""}`}>
      <h2 className="mb-5 text-center text-2xl font-normal leading-tight text-catalog-sale md:mb-6 md:text-[30px] md:font-normal md:leading-tight md:text-catalog-sale">{title}</h2>
      {products.length === 0 ? (
        <div className="rounded-sm border border-dashed py-16 text-center text-muted-foreground">No products found</div>
      ) : (
        <div className={`grid grid-cols-2 gap-x-2.5 gap-y-5 md:gap-x-4 md:gap-y-6 ${featured ? "md:grid-cols-4" : sixColumns ? "md:grid-cols-3 lg:grid-cols-6" : "md:grid-cols-3 lg:grid-cols-5"}`}>
          {products.map((p) => <ProductCard key={p.node.id} product={p} framed={featured && desktopOnly} mobileFramed={mobileFeatured} mobileQuickAdd={mobileQuickAdd} />)}
        </div>
      )}
      {more && <div className="mt-8 flex justify-center md:mt-7"><Button asChild variant="outline" className="h-10 rounded-full border-foreground px-5 text-sm font-medium md:h-9 md:border-catalog-border md:px-7 md:text-xs md:font-normal"><Link to="/collections/$slug" params={{ slug: moreSlug }}>View More Products</Link></Button></div>}
    </section>
  );
}

function Dots({ count, active, onSelect }: { count: number; active: number; onSelect: (i: number) => void }) {
  return (
    <div className="mt-5 flex items-center justify-center gap-4">
      {Array.from({ length: count }, (_, i) => (
        <button key={i} type="button" aria-label={`Slide ${i + 1}`} onClick={() => onSelect(i)} className="flex h-5 w-5 items-center justify-center">
          {i === active ? <span className="flex h-4 w-4 items-center justify-center rounded-full border border-foreground"><span className="h-1.5 w-1.5 rounded-full bg-foreground" /></span> : <span className="h-1.5 w-1.5 rounded-full bg-muted-foreground/40" />}
        </button>
      ))}
    </div>
  );
}

function MobileCarousel({ products, stacked = false, dots = true }: { products: ShopifyProduct[]; stacked?: boolean; dots?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(0);
  const pages = Math.max(1, Math.ceil(products.length / 2));
  return (
    <>
      <div
        ref={ref}
        onScroll={(e) => setActive(Math.min(pages - 1, Math.round(e.currentTarget.scrollLeft / e.currentTarget.clientWidth)))}
        className="flex snap-x snap-mandatory gap-3 overflow-x-auto [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
      >
        {products.map((p) => (
          <div key={p.node.id} className="w-[48.5%] shrink-0 snap-start">
            <ProductCard product={p} mobileFramed mobileStacked={stacked} />
          </div>
        ))}
      </div>
      {dots && pages > 1 && <Dots count={pages} active={active} onSelect={(i) => ref.current?.scrollTo({ left: i * ref.current.clientWidth, behavior: "smooth" })} />}
    </>
  );
}

const priceOf = (p: ShopifyProduct) => parseFloat(p.node.priceRange.minVariantPrice.amount);
const pick = (list: ShopifyProduct[], start: number, n: number, fallback?: ShopifyProduct[]) =>
  list.length ? list.slice(0, n) : (fallback ?? list).slice(start, start + n);

function Index() {
  const { data: all } = useSuspenseQuery(productsQuery);
  const { q, max } = Route.useSearch();

  if (q || max) {
    const results = all.filter(
      (p) => (!q || p.node.title.toLowerCase().includes(q.toLowerCase())) && (!max || priceOf(p) <= max),
    );
    return <main><Section id="products" title={q ? `Results for "${q}"` : `Deals under ₹${max}`} products={results} /></main>;
  }

  const discounted = all.filter((p) => {
    const v = p.node.variants.edges[0]?.node;
    return v?.compareAtPrice && parseFloat(v.compareAtPrice.amount) > parseFloat(v.price.amount);
  });
  const matching = (pattern: RegExp) => all.filter((p) => pattern.test(p.node.title));

  return (
    <main>
      <section className="mx-auto max-w-7xl px-6 pb-4 pt-3 md:px-4 md:pb-3 md:py-3">
        <div className="grid grid-cols-4 gap-x-3 gap-y-3 md:hidden">
          {MOBILE_CATEGORIES.map(({ label, image }) => (
            <Link key={label} to="/collections/$slug" params={{ slug: slugFor(label) }} className="flex min-w-0 flex-col items-center text-center">
              <img src={image} alt="" width={256} height={256} className="aspect-square w-full max-w-[72px] rounded-full object-cover" />
              <span className="mt-1 min-h-8 text-xs font-semibold leading-[18px]">{label}</span>
            </Link>
          ))}
        </div>
        <div className="hidden justify-between gap-2 pb-2 md:flex">
          {DESKTOP_CATEGORIES.map(({ label, image }) => (
            <Link key={label} to="/collections/$slug" params={{ slug: slugFor(label) }} className="group flex w-16 flex-col items-center text-center md:w-auto md:min-w-0 md:flex-1">
              <img src={image} alt="" width={256} height={256} className="h-16 w-16 rounded-full object-cover transition-transform motion-safe:group-hover:scale-95 lg:h-[76px] lg:w-[76px]" />
              <span className="mt-2 min-h-7 text-[10px] font-normal leading-tight xl:text-xs">{label}</span>
            </Link>
          ))}
          <Link to="/collections" className="flex w-16 flex-col items-center text-center md:w-auto md:min-w-0 md:flex-1">
            <span className="flex h-16 w-16 items-center justify-center rounded-full border border-catalog-border lg:h-[76px] lg:w-[76px]"><ArrowUpRight className="h-4 w-4" /></span>
            <span className="mt-2 min-h-7 text-[10px] font-normal leading-tight xl:text-xs">Shop All</span>
          </Link>
        </div>
      </section>

      <div className="md:hidden">
        <BannerSlider aspect="aspect-[400/206]" slides={SLIDES} />
      </div>
      <div className="mx-auto hidden max-w-7xl px-4 md:block">
        <BannerSlider aspect="aspect-[48/17]" slides={DESKTOP_SLIDES} />
      </div>

      <section className="mx-auto max-w-7xl px-6 py-6 md:px-4 md:pb-0 md:pt-7">
        <h2 className="mx-auto mb-6 max-w-80 text-center text-2xl font-bold leading-snug text-catalog-sale md:mb-5 md:max-w-none md:text-[30px] md:text-catalog-sale">Deals for Every Budget – Find Yours</h2>
        <div className="grid grid-cols-3 gap-x-2 gap-y-1.5 md:grid-cols-6 md:gap-2">
          {BUDGETS.map((b, i) => (
            <a
              key={i}
              href={b.max === Infinity ? "#products" : `/?max=${b.max}`}
              aria-label={`${b.label} ₹${b.price}`}
              className={`budget-tile budget-tile-${i % 3} relative flex aspect-[5/6] min-w-0 flex-col items-center justify-center overflow-hidden rounded-lg p-0 text-center transition-transform hover:-translate-y-1 md:aspect-[5/6] md:rounded-md md:p-0`}
            >
              <img src={MOBILE_BUDGET_IMAGES[i]} alt="" width={320} height={384} className="absolute inset-0 h-full w-full object-cover md:hidden" />
              <img src={BUDGET_IMAGES[i]} alt="" width={320} height={640} loading="lazy" className="absolute inset-0 hidden h-full w-full object-cover md:block" />
              <span className="absolute bottom-3 rounded-full bg-background px-3.5 py-2.5 text-[11px] font-medium leading-none text-foreground [text-shadow:none] md:px-4 md:py-1.5 md:text-[10px] md:leading-normal">Explore</span>
            </a>
          ))}
        </div>
        <div className="mt-2 border-t md:hidden" />
      </section>

      <div id="products" className="scroll-mt-40" />
      <div className="md:hidden">
        <section className="px-6 pb-6 pt-1">
          <h2 className="mb-6 text-center text-2xl font-normal leading-tight text-catalog-sale">✨Today's Must-Have Deal✨</h2>
          <MobileCarousel products={pick(discounted.length ? discounted : all, 0, 6)} />
        </section>
        <Section more title="Just Arrived - Check It Out" products={all.slice(0, 16)} />
        <Section more moreSlug="personalized-gifts" title="New Arrivals: Personalized Gifts" products={pick(matching(/personalized|custom/i), 16, 12, all)} />
        <Section more moreSlug="under-99" title="Find Deals Under ₹99" products={all.filter((p) => priceOf(p) <= 99).slice(0, 15)} />
        <Section mobileQuickAdd title="Fashion For Every Budget" products={pick(matching(/socks|hair clip|tote/i), 28, 6, all)} />
        <Section title="Special Price Drop Offer" products={(discounted.length ? discounted : all).slice(16, 22)} />
        <Section more moreSlug="on-sale" title="Don't Wait: Grab It Now, Limited Stock" products={all.slice(22, 42)} />
        <section className="px-6 pb-8 pt-6">
          <div className="relative rounded-lg border border-catalog-sale px-3 pb-6 pt-10">
            <h2 className="absolute -top-4 left-1/2 flex -translate-x-1/2 items-center gap-2 whitespace-nowrap bg-background px-3 text-2xl font-normal leading-none text-catalog-sale">
              <Zap className="h-7 w-7 fill-current" strokeWidth={1.5} aria-hidden />Trending Toys Alert!
            </h2>
            <MobileCarousel stacked dots={false} products={pick(matching(/toy|game/i), 42, 6, all)} />
          </div>
        </section>
      </div>
      <Section desktopOnly featured title="✨Today's Must-Have Deal✨" products={(discounted.length ? discounted : all).slice(0, 4)} />
      <Section desktopOnly id="desktop-products" more title="Just Arrived - Check It Out" products={all.slice(0, 16)} />
      <Section desktopOnly sixColumns more moreSlug="personalized-gifts" title="New Arrivals: Personalized Gifts" products={pick(matching(/personalized|custom/i), 16, 12, all)} />
      <Section desktopOnly more moreSlug="under-99" title="Find Deals Under ₹99" products={all.filter((p) => priceOf(p) <= 99).slice(0, 15)} />
      <Section desktopOnly sixColumns title="Fashion For Every Budget" products={pick(matching(/socks|hair clip|tote/i), 28, 6, all)} />
      <Section desktopOnly sixColumns title="Special Price Drop Offer" products={(discounted.length ? discounted : all).slice(16, 22)} />
      <Section desktopOnly more moreSlug="on-sale" title="Don't Wait: Grab It Now, Limited Stock" products={all.slice(22, 42)} />
      <section className="mx-auto hidden max-w-7xl px-4 pb-10 pt-10 md:block">
        <div className="relative rounded-lg border border-catalog-sale px-5 pb-8 pt-10">
          <h2 className="absolute -top-5 left-1/2 flex -translate-x-1/2 items-center gap-2 whitespace-nowrap bg-background px-4 text-[30px] font-normal leading-none text-catalog-sale">
            <Zap className="h-8 w-8 fill-current" strokeWidth={1.5} aria-hidden />Trending Toys Alert!
          </h2>
          <div className="grid gap-3 md:grid-cols-3 lg:grid-cols-6">
            {pick(matching(/toy|game/i), 42, 6, all).map((p) => <ProductCard key={p.node.id} product={p} framed />)}
          </div>
        </div>
      </section>
    </main>
  );
}

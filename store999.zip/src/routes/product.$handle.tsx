import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { fetchProduct } from "@/lib/shopify";
import { ProductDetail } from "@/components/ProductDetail";

const productQuery = (handle: string) =>
  queryOptions({ queryKey: ["product", handle], queryFn: () => fetchProduct(handle) });

export const Route = createFileRoute("/product/$handle")({
  loader: async ({ context, params }) => {
    const product = await context.queryClient.ensureQueryData(productQuery(params.handle));
    if (!product) throw notFound();
    return { title: product.node.title, description: product.node.description, image: product.node.images.edges[0]?.node.url };
  },
  head: ({ loaderData }) => {
    const title = loaderData ? `${loaderData.title} — BulkBazaar` : "Product — BulkBazaar";
    const description = loaderData?.description?.slice(0, 155) || "Shop this product at BulkBazaar.";
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "product" },
        { name: "twitter:card", content: "summary_large_image" },
        ...(loaderData?.image?.startsWith("https://") ? [
          { property: "og:image", content: loaderData.image },
          { name: "twitter:image", content: loaderData.image },
        ] : []),
      ],
    };
  },
  notFoundComponent: () => (
    <div className="mx-auto max-w-6xl px-6 py-24 text-center">
      <p className="text-muted-foreground">Product not found.</p>
      <Link to="/" className="mt-4 inline-block underline">Back to shop</Link>
    </div>
  ),
  component: ProductPage,
});

function ProductPage() {
  const { handle } = Route.useParams();
  const { data } = useSuspenseQuery(productQuery(handle));
  if (!data) return null;
  return <ProductDetail key={handle} product={data} />;
}

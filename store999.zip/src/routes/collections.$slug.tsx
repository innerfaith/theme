import { useMemo, useState } from "react";
import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { ChevronDown, ChevronRight, ChevronUp, PanelLeft, SlidersHorizontal, X } from "lucide-react";
import { fetchProducts, type ShopifyProduct } from "@/lib/shopify";
import { COLLECTIONS, findCollection } from "@/lib/collections";
import { ProductCard } from "@/components/ProductCard";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Sheet, SheetClose, SheetContent, SheetDescription, SheetTitle } from "@/components/ui/sheet";

const productsQuery = queryOptions({ queryKey: ["products"], queryFn: () => fetchProducts(250) });

export const Route = createFileRoute("/collections/$slug")({
  loader: async ({ context, params }) => {
    const c = findCollection(params.slug);
    if (!c) throw notFound();
    await context.queryClient.ensureQueryData(productsQuery);
    return { label: c.label };
  },
  head: ({ loaderData }) => {
    const label = loaderData?.label ?? "Collection";
    const title = `${label} – BulkBazaar wholesale deals`;
    const desc = `Shop ${label} at wholesale prices on BulkBazaar. Filter by price and availability.`;
    return {
      meta: [
        { title },
        { name: "description", content: desc },
        { property: "og:title", content: title },
        { property: "og:description", content: desc },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  notFoundComponent: () => (
    <main className="mx-auto max-w-7xl px-4 py-24 text-center">
      <h1 className="text-3xl">Collection not found</h1>
      <Link to="/collections" className="mt-4 inline-block text-sale underline">See all collections</Link>
    </main>
  ),
  component: CollectionPage,
});

const priceOf = (p: ShopifyProduct) => parseFloat(p.node.priceRange.minVariantPrice.amount);
const inStock = (p: ShopifyProduct) => p.node.variants.edges.some((v) => v.node.availableForSale);
const SORTS = {
  "date-desc": { label: "Date, new to old", fn: (_a: ShopifyProduct, _b: ShopifyProduct) => 0 },
  "price-asc": { label: "Price, low to high", fn: (a: ShopifyProduct, b: ShopifyProduct) => priceOf(a) - priceOf(b) },
  "price-desc": { label: "Price, high to low", fn: (a: ShopifyProduct, b: ShopifyProduct) => priceOf(b) - priceOf(a) },
  "title-asc": { label: "Alphabetically, A-Z", fn: (a: ShopifyProduct, b: ShopifyProduct) => a.node.title.localeCompare(b.node.title) },
} as const;
type SortKey = keyof typeof SORTS;
const COLS = { 1: "grid-cols-1", 2: "grid-cols-2", 3: "grid-cols-2 md:grid-cols-3", 4: "grid-cols-2 md:grid-cols-3 lg:grid-cols-4" } as const;

function FilterGroup({ title, children }: { title: string; children: React.ReactNode }) {
  const [open, setOpen] = useState(true);
  return (
    <div className="border-b pb-6 pt-2 last:border-b-0">
      <button type="button" onClick={() => setOpen((o) => !o)} className="flex w-full items-center justify-between py-3 text-xl font-normal">
        {title}{open ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
      </button>
      {open && <div className="mt-2">{children}</div>}
    </div>
  );
}

function CollectionPage() {
  const { slug } = Route.useParams();
  const { data: all } = useSuspenseQuery(productsQuery);
  const collection = findCollection(slug)!;
  const base = useMemo(() => collection.select(all), [collection, all]);
  const maxPrice = Math.max(1, Math.ceil(Math.max(0, ...all.map(priceOf))));
  const [range, setRange] = useState<[number, number]>([0, maxPrice]);
  const [stock, setStock] = useState<{ in: boolean; out: boolean }>({ in: false, out: false });
  const [sort, setSort] = useState<SortKey>("date-desc");
  const [cols, setCols] = useState<keyof typeof COLS>(4);
  const [mobileFilter, setMobileFilter] = useState(false);

  const products = base
    .filter((p) => priceOf(p) >= range[0] && priceOf(p) <= range[1])
    .filter((p) => (stock.in === stock.out ? true : stock.in ? inStock(p) : !inStock(p)))
    .slice()
    .sort(SORTS[sort].fn);
  const inCount = base.filter(inStock).length;

  const filters = (
    <>
      <FilterGroup title="Product categories">
        <ul className="max-h-[600px] space-y-1 overflow-y-auto border-r-2 border-foreground pr-3">
          {COLLECTIONS.map((c) => {
            const active = c.slug === slug;
            return (
              <li key={c.slug}>
                <Link to="/collections/$slug" params={{ slug: c.slug }} onClick={() => setMobileFilter(false)} className={`block py-1.5 text-sm transition-colors hover:text-sale ${active ? "font-medium text-sale" : "text-foreground"}`}>
                  {c.label} ({c.select(all).length})
                </Link>
              </li>
            );
          })}
        </ul>
      </FilterGroup>
      <FilterGroup title="Availability">
        <label className="flex items-center gap-3 py-1.5 text-sm"><Checkbox checked={stock.in} onCheckedChange={(v) => setStock((s) => ({ ...s, in: !!v }))} />In stock ({inCount})</label>
        <label className="flex items-center gap-3 py-1.5 text-sm"><Checkbox checked={stock.out} onCheckedChange={(v) => setStock((s) => ({ ...s, out: !!v }))} />Out of stock ({base.length - inCount})</label>
      </FilterGroup>
      <FilterGroup title="Price">
        <Slider min={0} max={maxPrice} step={1} value={range} onValueChange={(v) => setRange([v[0], v[1]] as [number, number])} className="my-4 [&_[role=slider]]:border-sale [&_[role=slider]]:bg-sale [&>span>span]:bg-sale" />
        <div className="mt-6 flex items-center gap-2 text-sm text-muted-foreground">
          Price:
          <span className="flex w-20 items-center gap-1 rounded border px-2 py-1.5">₹<input aria-label="Minimum price" type="number" value={range[0]} onChange={(e) => setRange([Number(e.target.value) || 0, range[1]])} className="w-full bg-transparent text-right outline-none" /></span>
          -
          <span className="flex w-20 items-center gap-1 rounded border px-2 py-1.5">₹<input aria-label="Maximum price" type="number" value={range[1]} onChange={(e) => setRange([range[0], Number(e.target.value) || 0])} className="w-full bg-transparent text-right outline-none" /></span>
        </div>
        <button type="button" onClick={() => { setRange([0, maxPrice]); setStock({ in: false, out: false }); }} className="mt-5 rounded-full bg-muted px-4 py-2 text-xs font-semibold">RESET</button>
      </FilterGroup>
    </>
  );

  const gridBtn = (n: keyof typeof COLS, dots: number, extra = "") => (
    <button key={n} type="button" aria-label={`${n} per row`} onClick={() => setCols(n)} className={`flex items-center gap-0.5 p-1 ${extra} ${cols === n ? "text-foreground" : "text-muted-foreground/50"}`}>
      {Array.from({ length: dots }, (_, i) => <span key={i} className={`flex flex-col gap-0.5`}><span className="h-1 w-1 rounded-full bg-current" /><span className="h-1 w-1 rounded-full bg-current" /></span>)}
    </button>
  );

  return (
    <main>
      <section className="px-4 pb-8 pt-10 text-center md:pb-14 md:pt-16">
        <h1 className="text-4xl font-normal md:text-6xl">{collection.label}</h1>
        <nav aria-label="Breadcrumb" className="mt-4 flex items-center justify-center gap-3 text-sm">
          <Link to="/" className="hover:text-sale">Home</Link><ChevronRight className="h-3.5 w-3.5" /><span className="text-muted-foreground">{collection.label}</span>
        </nav>
      </section>

      <div className="mx-auto max-w-7xl px-4 pb-16">
        <div className="mb-8 flex items-center justify-between gap-3">
          <Button variant="outline" onClick={() => setMobileFilter(true)} aria-haspopup="dialog" aria-expanded={mobileFilter} className="h-auto gap-2 rounded-full border-foreground/40 px-4 py-2.5 text-xs font-semibold">
            <SlidersHorizontal className="h-4 w-4" />FILTER
          </Button>
          <div className="hidden items-center gap-4 md:flex">
            {gridBtn(2, 2)}{gridBtn(3, 3)}{gridBtn(4, 4)}
          </div>
          <div className="flex items-center gap-2 md:hidden">{gridBtn(1, 1)}{gridBtn(2, 2)}</div>
          <label className="relative">
            <span className="sr-only">Sort by</span>
            <select value={sort} onChange={(e) => setSort(e.target.value as SortKey)} className="appearance-none rounded-full border border-foreground/40 bg-background py-2.5 pl-5 pr-10 text-sm text-muted-foreground outline-none">
              {Object.entries(SORTS).map(([k, s]) => <option key={k} value={k}>{s.label}</option>)}
            </select>
            <ChevronDown className="pointer-events-none absolute right-4 top-1/2 h-4 w-4 -translate-y-1/2" />
          </label>
        </div>

        <div className="flex gap-6">
          <aside className="hidden w-60 shrink-0 md:block">{filters}</aside>
          <div className="relative min-w-0 flex-1">
            <Button variant="outline" size="icon" aria-label="Open product filters" aria-haspopup="dialog" aria-expanded={mobileFilter} title="Product filters" onClick={() => setMobileFilter(true)} className="fixed left-0 top-1/2 z-30 h-9 w-9 -translate-y-1/2 rounded-l-none rounded-r-full border-foreground/30 bg-background md:hidden">
              <PanelLeft />
            </Button>
            <p className="mb-4 text-sm text-muted-foreground">{products.length} products</p>
            {products.length === 0 ? (
              <div className="rounded border border-dashed py-20 text-center text-muted-foreground">No products match these filters.</div>
            ) : (
              <div className={`grid gap-x-4 gap-y-8 ${COLS[cols]}`}>
                {products.map((p) => <ProductCard key={p.node.id} product={p} />)}
              </div>
            )}
          </div>
        </div>
      </div>

      <Sheet open={mobileFilter} onOpenChange={setMobileFilter}>
        <SheetContent side="left" className="flex h-dvh w-full max-w-none flex-col gap-0 p-0 duration-300 sm:max-w-none md:w-96 md:max-w-sm motion-reduce:animate-none motion-reduce:transition-none [&>button]:hidden">
          <SheetTitle className="sr-only">Filter</SheetTitle>
          <SheetDescription className="sr-only">Choose a product category, availability and price.</SheetDescription>
          <div className="flex h-12 shrink-0 items-center justify-between bg-muted px-3">
            <span className="flex items-center gap-2 text-sm font-semibold"><SlidersHorizontal className="h-4 w-4" />FILTER</span>
            <SheetClose asChild>
              <Button variant="ghost" size="icon" aria-label="Close filters" className="rounded-full hover:bg-muted"><X className="h-5 w-5" /></Button>
            </SheetClose>
          </div>
          <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain px-5 pb-4 [&_ul]:max-h-none [&_ul]:overflow-visible [&_ul]:border-r-0">{filters}</div>
          <div className="border-t bg-background p-4">
            <Button onClick={() => setMobileFilter(false)} className="h-11 w-full rounded-full text-sm font-semibold">Show {products.length} products</Button>
          </div>
        </SheetContent>
      </Sheet>
    </main>
  );
}

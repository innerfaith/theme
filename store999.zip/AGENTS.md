<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep phone-specific wholesale layouts behind the existing md breakpoint so desktop presentation remains independent.
- Category illustrations and promotional banners use local imported assets; real product content remains sourced from Shopify to avoid presenting fictional stock.
- Keep reference section composition in the home route with md-gated larger-screen sections, while sharing Shopify-backed product cards; this preserves independent phone presentation.
- Scope wholesale typography and featured-card framing to md+ with an explicit card presentation prop; this keeps phone cards and standard product grids independent.
- Use a separate mobile card framing prop and below-md CSS for phone reference composition; preserve all larger-screen card and layout rules.
- Extract only decorative reference imagery into asset pointers; keep reference product data and unverified customer or stock claims out of the store catalog.
- Collection pages are defined in one shared list (src/lib/collections.ts) used by the header, home category circles and /collections routes; keeps navigation and sidebar in sync.
- Footer shopping links resolve through the shared collection list; use expandable groups below md and columns above md so both presentations remain independent. Do not add placeholder contact details or link missing policy pages to the home page.
- Keep shared store motion in StoreMotion and global motion tokens; use one-shot viewport reveals with bounded row staggering, never transform layout ancestors of fixed controls or hijack native scrolling, and cancel motion for reduced-motion preferences and keyboard focus so shopping stays accessible.
- Product routes delegate presentation to a handle-keyed ProductDetail so gallery, quantity and variant state reset when products change; all displayed prices, savings and availability derive from Shopify.
